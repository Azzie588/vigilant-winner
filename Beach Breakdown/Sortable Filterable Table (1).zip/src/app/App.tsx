import { useState, useMemo } from "react";
import { ChevronUp, ChevronDown, ChevronsUpDown, Search, Bus, X, TableProperties, BookOpen } from "lucide-react";
import EasyRead from "./EasyRead";

type SortDir = "asc" | "desc" | null;
type ColKey =
  | "name"
  | "address"
  | "distance"
  | "transit"
  | "what"
  | "hours"
  | "notes"
  | "url";

interface Place {
  id: number;
  name: string;
  address: string;
  distance: number; // miles
  transit: string;
  transitAccessible: boolean;
  what: string;
  category: string;
  hours: string;
  notes: string;
  url: string;
}

const CATEGORIES = [
  "Food Pantry",
  "Medical",
  "Mental Health",
  "Housing",
  "Employment",
  "Legal Aid",
  "Youth Services",
  "Senior Services",
];

const DATA: Place[] = [
  {
    id: 1,
    name: "Bread of Life Food Pantry",
    address: "9400 S. Caribbean Ave, Chicago, IL 60617",
    distance: 0.1,
    transit: "Bus 93 (Chicago Ave) to Caribbean, 3 min walk",
    transitAccessible: true,
    what: "Weekly grocery distribution, fresh produce",
    category: "Food Pantry",
    hours: "Tue & Thu 10am–1pm",
    notes: "Bring proof of address. No ID required.",
    url: "https://breadoflifechicago.org",
  },
  {
    id: 2,
    name: "Roseland Community Hospital",
    address: "45 W. 111th St, Chicago, IL 60628",
    distance: 1.8,
    transit: "Bus 111 (111th St) direct, 12 min",
    transitAccessible: true,
    what: "Emergency & primary care, sliding-scale fees",
    category: "Medical",
    hours: "Emergency: 24/7 · Clinic: M–F 8am–5pm",
    notes: "Financial counselors on-site. Accepts Medicaid.",
    url: "https://roselandhospital.org",
  },
  {
    id: 3,
    name: "Greater Auburn-Gresham Development Corp",
    address: "839 W. 79th St, Chicago, IL 60620",
    distance: 2.3,
    transit: "Red Line to 79th St, 8 min walk",
    transitAccessible: true,
    what: "Job training, resume help, GED prep",
    category: "Employment",
    hours: "M–F 9am–5pm",
    notes: "Walk-ins welcome Mon & Wed mornings.",
    url: "https://gagdc.org",
  },
  {
    id: 4,
    name: "Thresholds South Side",
    address: "7700 S. Halsted St, Chicago, IL 60620",
    distance: 3.1,
    transit: "Bus 8 (Halsted) to 77th, 2 min walk",
    transitAccessible: true,
    what: "Mental health counseling, crisis stabilization",
    category: "Mental Health",
    hours: "M–F 8am–6pm · Crisis line 24/7",
    notes: "Accepts uninsured clients. Spanish-speaking staff available.",
    url: "https://thresholds.org",
  },
  {
    id: 5,
    name: "Chicago Legal Clinic – SE",
    address: "2938 E. 91st St, Chicago, IL 60617",
    distance: 0.9,
    transit: "Bus 93 (Chicago Ave) to 91st, 4 min walk",
    transitAccessible: true,
    what: "Free legal consultations: housing, immigration, benefits",
    category: "Legal Aid",
    hours: "Mon & Wed 5pm–8pm (by appointment)",
    notes: "Call ahead. Evening slots fill quickly.",
    url: "https://chicagolegalclinic.org",
  },
  {
    id: 6,
    name: "South Side YMCA",
    address: "6330 S. Stony Island Ave, Chicago, IL 60637",
    distance: 4.2,
    transit: "Drive or rideshare recommended; no direct bus route",
    transitAccessible: false,
    what: "Youth programs, afterschool tutoring, swim lessons",
    category: "Youth Services",
    hours: "M–F 6am–9pm · Sat 8am–6pm",
    notes: "Scholarship memberships available. Bring school enrollment record for youth discount.",
    url: "https://ymcachicago.org/south-side",
  },
  {
    id: 7,
    name: "Aunt Martha's – Pullman Health Center",
    address: "11004 S. Indiana Ave, Chicago, IL 60628",
    distance: 2.7,
    transit: "Metra Electric (111th St-Pullman), 9 min walk",
    transitAccessible: true,
    what: "Primary care, dental, behavioral health",
    category: "Medical",
    hours: "M–Th 8am–7pm · F 8am–5pm · Sat 9am–1pm",
    notes: "FQHC – sliding scale fees. Same-day appointments often available.",
    url: "https://auntmartha.org",
  },
  {
    id: 8,
    name: "Senior Connections – Far South",
    address: "1 E. 130th St, Chicago, IL 60827",
    distance: 5.6,
    transit: "No direct transit; Dial-a-Ride available for seniors 60+",
    transitAccessible: false,
    what: "Case management, Meals on Wheels, transportation assistance",
    category: "Senior Services",
    hours: "M–F 9am–4pm",
    notes: "Call to schedule Dial-a-Ride pickup. Income verification required for meal program.",
    url: "https://cityofchicago.org/seniors",
  },
  {
    id: 9,
    name: "Chicago Housing Authority – SE Office",
    address: "10300 S. Doty Ave, Chicago, IL 60628",
    distance: 3.4,
    transit: "Bus 4 (Cottage Grove) to 103rd, 6 min walk",
    transitAccessible: true,
    what: "Public housing applications, voucher program, rapid re-housing",
    category: "Housing",
    hours: "M–F 8:30am–4:30pm",
    notes: "Bring all household IDs and income documentation.",
    url: "https://thecha.org",
  },
  {
    id: 10,
    name: "Kingdom Life Church Pantry",
    address: "9536 S. Cottage Grove Ave, Chicago, IL 60628",
    distance: 1.4,
    transit: "Bus 4 (Cottage Grove) direct, 7 min",
    transitAccessible: true,
    what: "Monthly food distribution, hygiene kits",
    category: "Food Pantry",
    hours: "First Saturday of month, 9am–Noon",
    notes: "Open to all. Donations also accepted.",
    url: "https://kingdomlifechurch.net",
  },
];

function ViewBar({ view, setView }: { view: "table" | "easyread"; setView: (v: "table" | "easyread") => void }) {
  return (
    <div className="flex justify-center gap-2 py-2 px-4 bg-[#1b3a4b]">
      <button
        onClick={() => setView("table")}
        className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-bold transition-colors duration-150 ${
          view === "table"
            ? "bg-white text-[#1b3a4b]"
            : "text-white/70 hover:text-white"
        }`}
      >
        <TableProperties size={14} /> Full Table
      </button>
      <button
        onClick={() => setView("easyread")}
        className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-bold transition-colors duration-150 ${
          view === "easyread"
            ? "bg-white text-[#1b3a4b]"
            : "text-white/70 hover:text-white"
        }`}
      >
        <BookOpen size={14} /> Easy Read
      </button>
    </div>
  );
}

function SortIcon({ col, sortCol, sortDir }: { col: ColKey; sortCol: ColKey | null; sortDir: SortDir }) {
  if (sortCol !== col) return <ChevronsUpDown className="inline ml-1 opacity-30" size={13} />;
  if (sortDir === "asc") return <ChevronUp className="inline ml-1 text-primary" size={13} />;
  return <ChevronDown className="inline ml-1 text-primary" size={13} />;
}

export default function App() {
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const [transitFilter, setTransitFilter] = useState<string>("All");
  const [sortCol, setSortCol] = useState<ColKey | null>("distance");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  function handleSort(col: ColKey) {
    if (sortCol === col) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortCol(col);
      setSortDir("asc");
    }
  }

  const filtered = useMemo(() => {
    let rows = [...DATA];

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      rows = rows.filter(
        (r) => r.name.toLowerCase().includes(q) || r.what.toLowerCase().includes(q)
      );
    }
    if (categoryFilter !== "All") {
      rows = rows.filter((r) => r.category === categoryFilter);
    }
    if (transitFilter === "Yes") {
      rows = rows.filter((r) => r.transitAccessible);
    } else if (transitFilter === "No") {
      rows = rows.filter((r) => !r.transitAccessible);
    }

    if (sortCol) {
      rows.sort((a, b) => {
        let av: string | number = "";
        let bv: string | number = "";
        if (sortCol === "name") { av = a.name; bv = b.name; }
        else if (sortCol === "address") { av = a.address; bv = b.address; }
        else if (sortCol === "distance") { av = a.distance; bv = b.distance; }
        else if (sortCol === "transit") { av = a.transit; bv = b.transit; }
        else if (sortCol === "what") { av = a.what; bv = b.what; }
        else if (sortCol === "hours") { av = a.hours; bv = b.hours; }
        else if (sortCol === "notes") { av = a.notes; bv = b.notes; }
        else if (sortCol === "url") { av = a.url; bv = b.url; }

        if (typeof av === "number" && typeof bv === "number") {
          return sortDir === "asc" ? av - bv : bv - av;
        }
        const cmp = String(av).localeCompare(String(bv));
        return sortDir === "asc" ? cmp : -cmp;
      });
    }

    return rows;
  }, [search, categoryFilter, transitFilter, sortCol, sortDir]);

  const hasFilters = search || categoryFilter !== "All" || transitFilter !== "All";

  function clearAll() {
    setSearch("");
    setCategoryFilter("All");
    setTransitFilter("All");
  }

  const thClass =
    "px-3 py-2.5 text-left text-xs font-medium tracking-wide text-muted-foreground uppercase cursor-pointer select-none whitespace-nowrap hover:text-foreground transition-colors duration-150";
  const tdClass = "px-3 py-3 text-sm align-top leading-snug";

  const [view, setView] = useState<"table" | "easyread">("table");

  if (view === "easyread") {
    return (
      <div>
        <ViewBar view={view} setView={setView} />
        <EasyRead />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-background text-foreground"
      style={{ fontFamily: "'Nunito', sans-serif" }}
    >
      <ViewBar view={view} setView={setView} />
      {/* Header — ocean gradient band */}
      <div
        className="border-b border-border"
        style={{
          background: "linear-gradient(135deg, #0077b6 0%, #00b4d8 55%, #48cae4 100%)",
        }}
      >
        {/* Subtle wave divider at bottom */}
        <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 pt-6 pb-5">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4 mb-5">
            <div>
              <p className="text-xs font-semibold tracking-widest text-white/70 uppercase mb-1">
                🌊 Community Resource Directory
              </p>
              <h1
                className="text-3xl font-bold text-white drop-shadow-sm"
                style={{ letterSpacing: "-0.01em" }}
              >
                Resources Near 94th &amp; Caribbean
              </h1>
            </div>
            <div className="sm:ml-auto text-sm font-semibold text-white/80 self-center bg-white/20 rounded-full px-3 py-1">
              {filtered.length} of {DATA.length} spots
            </div>
          </div>

          {/* Controls */}
          <div className="flex flex-wrap gap-3 items-center">
            {/* Search */}
            <div className="relative">
              <Search
                size={14}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-[#0077b6] pointer-events-none"
              />
              <input
                type="text"
                placeholder="Search name or service…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 pr-3 py-2 text-sm rounded-full border-2 border-white/40 bg-white/90 placeholder:text-[#5e7e8a] text-[#1b3a4b] focus:outline-none focus:ring-2 focus:ring-white w-56 shadow-sm"
              />
            </div>

            {/* Category filter */}
            <div className="flex items-center gap-2">
              <label className="text-xs font-bold text-white/80 whitespace-nowrap">
                Category
              </label>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="text-sm rounded-full border-2 border-white/40 bg-white/90 text-[#1b3a4b] px-3 py-2 focus:outline-none focus:ring-2 focus:ring-white cursor-pointer shadow-sm font-semibold"
              >
                <option value="All">All</option>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Transit filter */}
            <div className="flex items-center gap-2">
              <label className="text-xs font-bold text-white/80 whitespace-nowrap flex items-center gap-1">
                <Bus size={13} />
                By Transit?
              </label>
              <select
                value={transitFilter}
                onChange={(e) => setTransitFilter(e.target.value)}
                className="text-sm rounded-full border-2 border-white/40 bg-white/90 text-[#1b3a4b] px-3 py-2 focus:outline-none focus:ring-2 focus:ring-white cursor-pointer shadow-sm font-semibold"
              >
                <option value="All">All</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>

            {/* Clear */}
            {hasFilters && (
              <button
                onClick={clearAll}
                className="flex items-center gap-1 text-xs font-bold text-white/70 hover:text-white transition-colors duration-150 ml-1 bg-white/10 hover:bg-white/20 rounded-full px-3 py-1.5"
              >
                <X size={12} />
                Clear
              </button>
            )}
          </div>
        </div>

        {/* SVG wave */}
        <svg viewBox="0 0 1440 28" className="w-full block" preserveAspectRatio="none" style={{ height: 28, marginBottom: -1 }}>
          <path
            d="M0,14 C240,28 480,0 720,14 C960,28 1200,0 1440,14 L1440,28 L0,28 Z"
            fill="#fef9ec"
          />
        </svg>
      </div>

      {/* Table container */}
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 py-6">
        <div
          className="rounded-2xl border-2 border-[rgba(0,150,160,0.18)] bg-card overflow-hidden shadow-md"
          style={{ overflowX: "auto" }}
        >
          <table className="w-full border-collapse" style={{ minWidth: 960 }}>
            <thead>
              <tr
                className="border-b-2 border-[rgba(0,150,160,0.15)]"
                style={{ background: "linear-gradient(90deg, #d4eeef 0%, #fdefc8 100%)" }}
              >
                {(
                  [
                    { key: "name", label: "Name" },
                    { key: "address", label: "Address" },
                    { key: "distance", label: "Distance" },
                    { key: "transit", label: "Public Transportation Detail" },
                    { key: "what", label: "What" },
                    { key: "hours", label: "Hours" },
                    { key: "notes", label: "Notes" },
                    { key: "url", label: "URL" },
                  ] as { key: ColKey; label: string }[]
                ).map(({ key, label }) => (
                  <th
                    key={key}
                    className={thClass}
                    onClick={() => handleSort(key)}
                  >
                    {label}
                    <SortIcon col={key} sortCol={sortCol} sortDir={sortDir} />
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td
                    colSpan={8}
                    className="px-3 py-12 text-center text-sm text-muted-foreground"
                  >
                    🏖️ No results match your filters.
                  </td>
                </tr>
              ) : (
                filtered.map((row, i) => (
                  <tr
                    key={row.id}
                    className={`border-b border-border last:border-0 transition-colors duration-100 hover:bg-[#d4eeef]/40 ${
                      i % 2 === 0 ? "bg-card" : "bg-[#fef9ec]"
                    }`}
                  >
                    {/* Name */}
                    <td className={tdClass}>
                      <div className="font-bold text-foreground leading-tight">
                        {row.name}
                      </div>
                    </td>

                    {/* Address */}
                    <td className={`${tdClass} text-muted-foreground max-w-[160px]`}>
                      {row.address}
                    </td>

                    {/* Distance */}
                    <td
                      className={tdClass}
                      style={{ fontFamily: "'DM Mono', monospace" }}
                    >
                      <span className="text-[#0077b6] font-bold">
                        {row.distance.toFixed(1)}
                      </span>
                      <span className="text-muted-foreground text-xs ml-0.5">mi</span>
                    </td>

                    {/* Transit */}
                    <td className={`${tdClass} max-w-[200px]`}>
                      <div className="flex items-start gap-1.5">
                        {row.transitAccessible ? (
                          <span className="mt-0.5 shrink-0 w-2.5 h-2.5 rounded-full bg-[#0096a0] inline-block shadow-sm" title="Transit accessible" />
                        ) : (
                          <span className="mt-0.5 shrink-0 w-2.5 h-2.5 rounded-full bg-muted-foreground/30 inline-block" title="Not transit accessible" />
                        )}
                        <span className="text-muted-foreground text-sm leading-snug">
                          {row.transit}
                        </span>
                      </div>
                    </td>

                    {/* What */}
                    <td className={`${tdClass} max-w-[200px] text-foreground font-medium`}>
                      {row.what}
                    </td>

                    {/* Hours */}
                    <td
                      className={`${tdClass} text-muted-foreground whitespace-pre-line`}
                      style={{ fontFamily: "'DM Mono', monospace", fontSize: "0.72rem" }}
                    >
                      {row.hours}
                    </td>

                    {/* Notes */}
                    <td className={`${tdClass} text-muted-foreground text-xs max-w-[200px] leading-relaxed`}>
                      {row.notes}
                    </td>

                    {/* URL */}
                    <td className={`${tdClass} max-w-[140px]`}>
                      <a
                        href={row.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#0096a0] text-xs font-semibold underline underline-offset-2 decoration-[#0096a0]/40 hover:decoration-[#0096a0] transition-colors duration-150 break-all"
                      >
                        {row.url.replace(/^https?:\/\//, "")}
                      </a>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Legend */}
        <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0096a0] inline-block" />
            Transit accessible
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-muted-foreground/30 inline-block" />
            No direct transit
          </div>
          <div className="ml-auto font-medium">
            📍 Distances from 94th St &amp; Caribbean Ave, Chicago IL
          </div>
        </div>
      </div>
    </div>
  );
}
