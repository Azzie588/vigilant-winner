import { useState, useMemo } from "react";
import { Search, Bus, X, Phone, Clock, MapPin, ExternalLink, ChevronUp, ChevronDown } from "lucide-react";

interface Place {
  id: number;
  name: string;
  address: string;
  phone: string;
  distance: number;
  transitAccessible: boolean;
  transit: string;
  what: string;
  category: string;
  hours: string;
  notes: string;
  url: string;
}

const CATEGORIES = [
  "Food Pantry",
  "Medical",
  "Mental Health",
  "Housing",
  "Employment",
  "Legal Aid",
  "Youth Services",
  "Senior Services",
];

const DATA: Place[] = [
  {
    id: 1,
    name: "Bread of Life Food Pantry",
    address: "9400 S. Caribbean Ave, Chicago, IL 60617",
    phone: "(773) 721-8008",
    distance: 0.1,
    transit: "Bus 93 to Caribbean — 3 min walk",
    transitAccessible: true,
    what: "Weekly groceries and fresh produce",
    category: "Food Pantry",
    hours: "Tuesday & Thursday\n10:00 am – 1:00 pm",
    notes: "Bring proof of address. No ID required.",
    url: "https://breadoflifechicago.org",
  },
  {
    id: 2,
    name: "Roseland Community Hospital",
    address: "45 W. 111th St, Chicago, IL 60628",
    phone: "(773) 995-3000",
    distance: 1.8,
    transit: "Bus 111 direct — 12 min ride",
    transitAccessible: true,
    what: "Emergency care and doctor visits, sliding-scale fees",
    category: "Medical",
    hours: "Emergency: Open 24 hours\nClinic: Mon–Fri, 8:00 am – 5:00 pm",
    notes: "Financial counselors on-site. Accepts Medicaid.",
    url: "https://roselandhospital.org",
  },
  {
    id: 3,
    name: "Greater Auburn-Gresham Dev. Corp",
    address: "839 W. 79th St, Chicago, IL 60620",
    phone: "(773) 483-3696",
    distance: 2.3,
    transit: "Red Line to 79th St — 8 min walk",
    transitAccessible: true,
    what: "Job training, resume help, GED prep",
    category: "Employment",
    hours: "Monday–Friday\n9:00 am – 5:00 pm",
    notes: "Walk-ins welcome Monday & Wednesday mornings.",
    url: "https://gagdc.org",
  },
  {
    id: 4,
    name: "Thresholds South Side",
    address: "7700 S. Halsted St, Chicago, IL 60620",
    phone: "(773) 878-3700",
    distance: 3.1,
    transit: "Bus 8 (Halsted) to 77th — 2 min walk",
    transitAccessible: true,
    what: "Mental health counseling and crisis support",
    category: "Mental Health",
    hours: "Mon–Fri, 8:00 am – 6:00 pm\nCrisis line: Open 24 hours",
    notes: "Accepts uninsured clients. Spanish-speaking staff available.",
    url: "https://thresholds.org",
  },
  {
    id: 5,
    name: "Chicago Legal Clinic – SE",
    address: "2938 E. 91st St, Chicago, IL 60617",
    phone: "(773) 731-1762",
    distance: 0.9,
    transit: "Bus 93 to 91st — 4 min walk",
    transitAccessible: true,
    what: "Free legal help: housing, immigration, benefits",
    category: "Legal Aid",
    hours: "Monday & Wednesday\n5:00 pm – 8:00 pm (appointment only)",
    notes: "Call ahead — evening slots fill quickly.",
    url: "https://chicagolegalclinic.org",
  },
  {
    id: 6,
    name: "South Side YMCA",
    address: "6330 S. Stony Island Ave, Chicago, IL 60637",
    phone: "(773) 947-0700",
    distance: 4.2,
    transit: "No direct bus — drive or rideshare recommended",
    transitAccessible: false,
    what: "Youth programs, afterschool tutoring, swim lessons",
    category: "Youth Services",
    hours: "Mon–Fri, 6:00 am – 9:00 pm\nSaturday, 8:00 am – 6:00 pm",
    notes: "Scholarship memberships available.",
    url: "https://ymcachicago.org/south-side",
  },
  {
    id: 7,
    name: "Aunt Martha's – Pullman Health",
    address: "11004 S. Indiana Ave, Chicago, IL 60628",
    phone: "(708) 754-1044",
    distance: 2.7,
    transit: "Metra Electric (111th/Pullman) — 9 min walk",
    transitAccessible: true,
    what: "Primary care, dental, and behavioral health",
    category: "Medical",
    hours: "Mon–Thu, 8:00 am – 7:00 pm\nFri, 8:00 am – 5:00 pm\nSat, 9:00 am – 1:00 pm",
    notes: "Sliding-scale fees. Same-day appointments often available.",
    url: "https://auntmartha.org",
  },
  {
    id: 8,
    name: "Senior Connections – Far South",
    address: "1 E. 130th St, Chicago, IL 60827",
    phone: "(312) 744-6010",
    distance: 5.6,
    transit: "Dial-a-Ride available for seniors age 60+",
    transitAccessible: false,
    what: "Case management, Meals on Wheels, transportation help",
    category: "Senior Services",
    hours: "Monday–Friday\n9:00 am – 4:00 pm",
    notes: "Call to schedule Dial-a-Ride pickup. Income verification required for meal program.",
    url: "https://cityofchicago.org/seniors",
  },
  {
    id: 9,
    name: "Chicago Housing Authority – SE",
    address: "10300 S. Doty Ave, Chicago, IL 60628",
    phone: "(312) 742-8500",
    distance: 3.4,
    transit: "Bus 4 (Cottage Grove) to 103rd — 6 min walk",
    transitAccessible: true,
    what: "Public housing, vouchers, and rapid re-housing",
    category: "Housing",
    hours: "Monday–Friday\n8:30 am – 4:30 pm",
    notes: "Bring all household IDs and income documentation.",
    url: "https://thecha.org",
  },
  {
    id: 10,
    name: "Kingdom Life Church Pantry",
    address: "9536 S. Cottage Grove Ave, Chicago, IL 60628",
    phone: "(773) 721-3300",
    distance: 1.4,
    transit: "Bus 4 (Cottage Grove) direct — 7 min ride",
    transitAccessible: true,
    what: "Monthly food distribution and hygiene kits",
    category: "Food Pantry",
    hours: "First Saturday of each month\n9:00 am – 12:00 pm (Noon)",
    notes: "Open to everyone. Donations also welcome.",
    url: "https://kingdomlifechurch.net",
  },
];

type SortField = "name" | "distance" | "category";

export default function EasyRead() {
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [transitFilter, setTransitFilter] = useState("All");
  const [sortField, setSortField] = useState<SortField>("distance");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  function toggleSort(field: SortField) {
    if (sortField === field) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  }

  const filtered = useMemo(() => {
    let rows = [...DATA];
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      rows = rows.filter(
        (r) => r.name.toLowerCase().includes(q) || r.what.toLowerCase().includes(q)
      );
    }
    if (categoryFilter !== "All") rows = rows.filter((r) => r.category === categoryFilter);
    if (transitFilter === "Yes") rows = rows.filter((r) => r.transitAccessible);
    if (transitFilter === "No") rows = rows.filter((r) => !r.transitAccessible);

    rows.sort((a, b) => {
      let cmp = 0;
      if (sortField === "distance") cmp = a.distance - b.distance;
      else if (sortField === "name") cmp = a.name.localeCompare(b.name);
      else if (sortField === "category") cmp = a.category.localeCompare(b.category);
      return sortDir === "asc" ? cmp : -cmp;
    });

    return rows;
  }, [search, categoryFilter, transitFilter, sortField, sortDir]);

  const hasFilters = search || categoryFilter !== "All" || transitFilter !== "All";

  const SortBtn = ({ field, label }: { field: SortField; label: string }) => (
    <button
      onClick={() => toggleSort(field)}
      className={`flex items-center gap-1 px-4 py-2 rounded-full text-base font-bold border-2 transition-colors duration-150 ${
        sortField === field
          ? "bg-[#1b3a4b] text-white border-[#1b3a4b]"
          : "bg-white text-[#1b3a4b] border-[#1b3a4b]/30 hover:border-[#1b3a4b]/70"
      }`}
    >
      {label}
      {sortField === field ? (
        sortDir === "asc" ? <ChevronUp size={16} /> : <ChevronDown size={16} />
      ) : null}
    </button>
  );

  return (
    <div className="min-h-screen bg-[#fef9ec]" style={{ fontFamily: "'Nunito', sans-serif" }}>

      {/* Header */}
      <div
        style={{
          background: "linear-gradient(135deg, #0077b6 0%, #00b4d8 55%, #48cae4 100%)",
        }}
      >
        <div className="max-w-3xl mx-auto px-5 pt-8 pb-5">
          <p className="text-base font-bold tracking-widest text-white/70 uppercase mb-1">
            🌊 Easy Read — Community Resources
          </p>
          <h1 className="text-4xl font-bold text-white leading-tight mb-1">
            Help Near 94th &amp; Caribbean
          </h1>
          <p className="text-xl text-white/85 font-semibold">
            Chicago, IL — {filtered.length} location{filtered.length !== 1 ? "s" : ""} shown
          </p>
        </div>

        {/* Search & filters */}
        <div className="max-w-3xl mx-auto px-5 pb-5 flex flex-col gap-4">
          {/* Search */}
          <div className="relative">
            <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#0077b6] pointer-events-none" />
            <input
              type="text"
              placeholder="Search by name or service…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-11 pr-4 py-3.5 text-lg rounded-2xl border-2 border-white/40 bg-white placeholder:text-[#5e7e8a] text-[#1b3a4b] focus:outline-none focus:ring-4 focus:ring-white/50 font-semibold shadow-sm"
            />
          </div>

          {/* Filter row */}
          <div className="flex flex-wrap gap-3 items-center">
            <div className="flex items-center gap-2">
              <label className="text-base font-bold text-white whitespace-nowrap">Type:</label>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="text-base font-bold rounded-2xl border-2 border-white/40 bg-white text-[#1b3a4b] px-4 py-3 focus:outline-none focus:ring-4 focus:ring-white/50 cursor-pointer shadow-sm"
              >
                <option value="All">All types</option>
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-base font-bold text-white whitespace-nowrap flex items-center gap-1">
                <Bus size={16} /> Bus/Train?
              </label>
              <select
                value={transitFilter}
                onChange={(e) => setTransitFilter(e.target.value)}
                className="text-base font-bold rounded-2xl border-2 border-white/40 bg-white text-[#1b3a4b] px-4 py-3 focus:outline-none focus:ring-4 focus:ring-white/50 cursor-pointer shadow-sm"
              >
                <option value="All">All</option>
                <option value="Yes">Yes — reachable by bus or train</option>
                <option value="No">No — need a ride</option>
              </select>
            </div>

            {hasFilters && (
              <button
                onClick={() => { setSearch(""); setCategoryFilter("All"); setTransitFilter("All"); }}
                className="flex items-center gap-1.5 text-base font-bold text-white bg-white/20 hover:bg-white/30 rounded-2xl px-4 py-3 transition-colors"
              >
                <X size={16} /> Clear all
              </button>
            )}
          </div>
        </div>

        {/* Wave */}
        <svg viewBox="0 0 1440 28" className="w-full block" preserveAspectRatio="none" style={{ height: 28, marginBottom: -1 }}>
          <path d="M0,14 C240,28 480,0 720,14 C960,28 1200,0 1440,14 L1440,28 L0,28 Z" fill="#fef9ec" />
        </svg>
      </div>

      {/* Sort controls */}
      <div className="max-w-3xl mx-auto px-5 pt-5 pb-2">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-base font-bold text-[#1b3a4b]">Sort by:</span>
          <SortBtn field="distance" label="Distance" />
          <SortBtn field="name" label="Name" />
          <SortBtn field="category" label="Type" />
        </div>
      </div>

      {/* Cards */}
      <div className="max-w-3xl mx-auto px-5 py-4 flex flex-col gap-5">
        {filtered.length === 0 ? (
          <div className="text-center py-16 text-2xl font-bold text-[#5e7e8a]">
            🏖️ No results found. Try different filters.
          </div>
        ) : (
          filtered.map((row) => (
            <div
              key={row.id}
              className="bg-white rounded-3xl border-2 border-[rgba(0,150,160,0.18)] shadow-sm overflow-hidden"
            >
              {/* Card top bar — category color strip */}
              <div className="h-2 w-full bg-gradient-to-r from-[#0096a0] to-[#48cae4]" />

              <div className="p-6">
                {/* Name + category */}
                <div className="flex flex-wrap items-start justify-between gap-2 mb-1">
                  <h2 className="text-2xl font-bold text-[#1b3a4b] leading-tight">
                    {row.name}
                  </h2>
                  <span className="text-sm font-bold px-3 py-1 rounded-full bg-[#fdefc8] text-[#7a4f00] border border-[#f4a261]/40 whitespace-nowrap">
                    {row.category}
                  </span>
                </div>

                {/* What */}
                <p className="text-xl text-[#1b3a4b] font-semibold mb-5 leading-snug">
                  {row.what}
                </p>

                {/* Info grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

                  {/* Address + distance */}
                  <div className="flex gap-3">
                    <MapPin size={22} className="shrink-0 mt-0.5 text-[#0096a0]" />
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-[#5e7e8a] mb-0.5">Address</p>
                      <p className="text-lg font-semibold text-[#1b3a4b] leading-snug">{row.address}</p>
                      <p className="text-base text-[#0077b6] font-bold mt-0.5">{row.distance.toFixed(1)} miles away</p>
                    </div>
                  </div>

                  {/* Hours */}
                  <div className="flex gap-3">
                    <Clock size={22} className="shrink-0 mt-0.5 text-[#0096a0]" />
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-[#5e7e8a] mb-0.5">Hours</p>
                      <p className="text-lg font-semibold text-[#1b3a4b] leading-snug whitespace-pre-line">{row.hours}</p>
                    </div>
                  </div>

                  {/* Phone */}
                  <div className="flex gap-3">
                    <Phone size={22} className="shrink-0 mt-0.5 text-[#0096a0]" />
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-[#5e7e8a] mb-0.5">Phone</p>
                      <a
                        href={`tel:${row.phone.replace(/\D/g, "")}`}
                        className="text-xl font-bold text-[#0077b6] underline underline-offset-2 hover:text-[#005f8a] transition-colors"
                      >
                        {row.phone}
                      </a>
                    </div>
                  </div>

                  {/* Transit */}
                  <div className="flex gap-3">
                    <Bus size={22} className="shrink-0 mt-0.5 text-[#0096a0]" />
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-[#5e7e8a] mb-0.5">
                        Getting There
                      </p>
                      <div className="flex items-center gap-2 mb-1">
                        {row.transitAccessible ? (
                          <span className="inline-flex items-center gap-1 text-sm font-bold text-white bg-[#0096a0] rounded-full px-2.5 py-0.5">
                            ✓ Bus / Train
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-sm font-bold text-[#5e7e8a] bg-[#eeece6] rounded-full px-2.5 py-0.5">
                            Need a Ride
                          </span>
                        )}
                      </div>
                      <p className="text-base font-semibold text-[#1b3a4b] leading-snug">{row.transit}</p>
                    </div>
                  </div>
                </div>

                {/* Notes */}
                {row.notes && (
                  <div className="mt-4 bg-[#fef9ec] border border-[rgba(0,150,160,0.15)] rounded-2xl px-4 py-3">
                    <p className="text-xs font-bold uppercase tracking-wide text-[#5e7e8a] mb-1">Good to Know</p>
                    <p className="text-base font-semibold text-[#1b3a4b] leading-relaxed">{row.notes}</p>
                  </div>
                )}

                {/* Website */}
                <div className="mt-4">
                  <a
                    href={row.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-base font-bold text-[#0096a0] underline underline-offset-2 hover:text-[#005f8a] transition-colors"
                  >
                    <ExternalLink size={16} />
                    {row.url.replace(/^https?:\/\//, "")}
                  </a>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      <div className="max-w-3xl mx-auto px-5 py-6 text-center text-base font-semibold text-[#5e7e8a]">
        📍 All distances measured from 94th St &amp; Caribbean Ave, Chicago IL
      </div>
    </div>
  );
}
